using System;

namespace Lessons
{
    public enum TypeCar //enum типов машин
    {
        Sport,
        Buss,
        NotCar
    }
}
